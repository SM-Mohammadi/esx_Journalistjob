INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_Journalist', 'Journalist', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_Journalist', 'Journalist', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_Journalist', 'Journalist', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('Journalist','Journalist')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('Journalist',0,'Filmbardar','Filmbardar',20,'{}','{}'),
	('Journalist',1,'Sedabardar','Sedabardar',40,'{}','{}'),
	('Journalist',2,'Gozareshgar','Gozareshgar',60,'{}','{}'),
	('Journalist',3,'Moaven','Moaven',85,'{}','{}'),
	('Journalist',4,'Rais','Rais',100,'{}','{}')
;
